<p 
    <div align="center">
    <a href="https://telegram.me/titanteams">
        <img src="http://upir.ir/951/guest/Untitled-7.png" hspace="10" width="150">
    </a>
    <a href="https://telegram.me/mohammadrezajiji">
        <img src="http://upir.ir/951/guest/Untitled-6.png" width="150">
    </a>
</div>
<a href="https://telegram.me/titanteams"><font size="100">parsol.v3</font></a>
<h3><p dir="rtl">سورسی کاملا فارسی در زمینه تیجی های جدید :)
<br>
<h3 align="right"> <strong></strong>
</h3>
<hr>
<h4 dir="rtl">دستورات</h4>
<h6>| راهنما | , ...</h6>
<hr>
</pre>
<h4 dir="rtl">درصورتی که سرور شما رایگان یا خام است بهتر است ابتدا کد اماده سازی سرور رو وارد کنید
</h4>
<pre>
<span>sudo apt-get update; sudo apt-get upgrade; sudo apt-get install tmux; sudo apt-get install luarocks; sudo apt-get install screen; sudo apt-get install libreadline-dev libconfig-dev libssl-dev lua5.2 liblua5.2-dev lua-socket lua-sec lua-expat libevent-dev make unzip git redis-server autoconf g++ libjansson-dev libpython-dev expat libexpat1-dev; sudo apt-get update; sudo apt-get install; sudo apt-get install upstart-sysv;
</span>
</pre>
<hr>
<h3 align="right"> <strong>نصب</strong> 🚀
<h4 dir="rtl">نصب ربات(روش اول)
<br></h4>
<h6 dir="rtl"></h6>
<pre>
<span>cd $HOME</span>
<span>git clone https://github.com/mohammadrezatitan/parsol.git</span>
<span>cd parsol</span>
<span>chmod +x parsol.sh</span>
<span>./parsol.sh install</span>
</pre>
<h4 dir="rtl">نصب ربات(روش دوم)
<br></h4>
<h6 dir="rtl"></h6>
<pre>
<span>cd $HOME && git clone https://github.com/mohammadrezatitan/parsol.git && cd parsol && chmod +x parsol.sh && ./parsol.sh install && ./parsol.sh 
</span>
</pre>
<hr>
<h4 dir="rtl">تایین سودو برای ربات
<h5 dir="rtl">ایدی عددی خودتون رو پس از نصب در خط 24 [config]  در پوشه  [data] همچنین خط 2 [tools] در پوشه [plugins] بگذارید سپس کد لانچ را وارد کنید✔️
</h6>
<pre>
    sudo_users = {
    267785153,
    YourID
    </pre>
<hr>
<h4 dir="rtl">🔃 لانچ و راه اندازی
<h6 dir="rtl">لانچ
<pre>
<span>killall screen</span>
<span>killall .telegram-cli</span>
<span>cd parsol</span>
<span>screen ./parsol.sh</span>
</pre>
<h6 dir="rtl">ابتدا یک توکن از @botfather دریافت کنید سپس توکن رو به جای عبارت [token] در auto.sh قرار دهید و کد های زیر را در ترمینال وارد کنید
<h5 dir="rtl">اتولانچ (بدون خاموشی)
<pre>
cd parsol
chmod +x ./auto.sh
screen ./auto.sh
</pre>
</P>


اموزش های بیش تر در کانال

# [mohammadrezajiji](https://telegram.me/mohammadrezajiji)


###  Telegram channel:

# [Titanteam](https://telegram.me/titantims)

### thanks to   

# [beyondteam](https://telegram.me/BeyondTeam)

# [luaerror](https://telegram.me/luaerror)

* * *
》*Please send us your stars☆ at the top of this page*


